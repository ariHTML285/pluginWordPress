<? function rz_install() {
    // создаем таблицу для хранения расписания занятий
    global $wpdb;
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

    /*$table_name = $wpdb->prefix . 'rz_schedule';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE $table_name (
        id int(11) NOT NULL AUTO_INCREMENT,
        date date NOT NULL,
        time time NOT NULL,
        title text NOT NULL,
        description text DEFAULT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    dbDelta( $sql );*/

    // create table discipline
    //
    $table_name = $wpdb->prefix . 'rz_discipline';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE `discipline` (
        `id` INT(11) PRIMARY KEY,
        `dis_name` VARCHAR(50) NOT NULL
    )$charset_collate;";
    dbDelta( $sql );

    //
    //
    $table_name = $wpdb->prefix . 'rz_type_disc';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE `type_disc` (
      `id` INT(11) PRIMARY KEY,
      `type_name` VARCHAR(50) NOT NULL
    )$charset_collate;";
    dbDelta( $sql );

    /*//
    //
    $table_name = $wpdb->prefix . 'discipline';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE `discipline` (
        `id` INT PRIMARY KEY,
        `dis_name` VARCHAR(50) NOT NULL
    )$charset_collate;";
    dbDelta( $sql );

    //
    //
    $table_name = $wpdb->prefix . 'discipline';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE `discipline` (
        `id` INT PRIMARY KEY,
        `dis_name` VARCHAR(50) NOT NULL
    )$charset_collate;";
    dbDelta( $sql );

    //
    $table_name = $wpdb->prefix . 'discipline';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE `discipline` (
        `id` INT PRIMARY KEY,
        `dis_name` VARCHAR(50) NOT NULL
    )$charset_collate;";
    dbDelta( $sql );

    //
    $table_name = $wpdb->prefix . 'discipline';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE `discipline` (
        `id` INT PRIMARY KEY,
        `dis_name` VARCHAR(50) NOT NULL
    )$charset_collate;";
    dbDelta( $sql );

    //
    $table_name = $wpdb->prefix . 'discipline';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE `discipline` (
        `id` INT PRIMARY KEY,
        `dis_name` VARCHAR(50) NOT NULL
    )$charset_collate;";
    dbDelta( $sql );*/
}
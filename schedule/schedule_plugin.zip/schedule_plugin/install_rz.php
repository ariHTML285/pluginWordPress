<? function rz_install() {
    // создаем таблицу для хранения расписания занятий
    global $wpdb;
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );


    // мы создадим таблицу дисциплины (rz_discipline) для хранения различных преподаваемых предметов
    //
    $table_name = $wpdb->prefix . 'rz_discipline';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS `rz_discipline` (
        `id` INT(11) PRIMARY KEY AUTO_INCREMENT,
        `dis_name` VARCHAR(50) NOT NULL
    )$charset_collate;";
    dbDelta( $sql );

    //(rz_type_disc)эта таблица позволит вам узнать тип курса.(лаб, практ)
    //
    $table_name = $wpdb->prefix . 'rz_type_disc';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS `rz_type_disc` (
      `id` INT(11) PRIMARY KEY AUTO_INCREMENT,
      `type_name` VARCHAR(50) NOT NULL
    )$charset_collate;";
    dbDelta( $sql );

    //эта таблица (rz_teacher) используется для сохранения имен преподавателей
    //
    $table_name = $wpdb->prefix . 'rz_teacher';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS `rz_teacher` (
      `id` INT(11) PRIMARY KEY AUTO_INCREMENT,
      `full_name` VARCHAR(50) NOT NULL
    )$charset_collate;";
    dbDelta( $sql );

    //эта таблица (rz_auditoriya) используется для сохранения комнат, в которых будут проводиться занятия
    //
    $table_name = $wpdb->prefix . 'rz_auditoriya';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS `rz_auditorium` (
      `id` INT(11) PRIMARY KEY AUTO_INCREMENT,
      `num_auditoriya` VARCHAR(10) NOT NULL,
      `name_auditoriya`
    )$charset_collate;";
    dbDelta( $sql );
    //
    //в этой таблице (rz_semester) хранится семестр каждого учебного года
    //
    $table_name = $wpdb->prefix . 'rz_semester';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS `rz_semester` (
      `id` INT(11) PRIMARY KEY AUTO_INCREMENT,
      `semester_name` VARCHAR(50) NOT NULL
    )$charset_collate;";
    dbDelta( $sql );

    //в этой таблице хранится факультет
    //
    $table_name = $wpdb->prefix . 'rz_faculty';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS `rz_faculty` (
      `id` INT(11) PRIMARY KEY AUTO_INCREMENT,
      `faculty_name` VARCHAR(50) NOT NULL
    )$charset_collate;";
    dbDelta( $sql );

    //в этой таблице (rz_speciality) хранится выбранное направление
    //
    $table_name = $wpdb->prefix . 'rz_speciality';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS `rz_speciality` (
      `id` INT(11) PRIMARY KEY AUTO_INCREMENT,
      `speciality_name` VARCHAR(50) NOT NULL,
      `faculty_id` INT(11) NOT NULL,
      FOREIGN KEY (`faculty_id`) REFERENCES `rz_faculty` (`id`)
    )$charset_collate;";
    dbDelta( $sql );

    //в этой таблице (rz_group) хранится группа учащихся
    //
    $table_name = $wpdb->prefix . 'rz_group';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS `rz_group` (
      `id` INT(11) PRIMARY KEY,
      `num_group` INT(5) NOT NULL,
      `speciality_id` INT(11) NOT NULL,
      `year_pastupit` INT(4),
      FOREIGN KEY (`speciality_id`) REFERENCES `rz_speciality` (`id`)
    )$charset_collate;";
    dbDelta( $sql );

    //в этой таблице (rz_schedule) хранится расписание занятий для каждой группы
    //
    $table_name = $wpdb->prefix . 'rz_schedule';
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS `rz_schedule` (
      `id` INT(11) PRIMARY KEY AUTO_INCREMENT,
      `num_para` VARCHAR(10),
      `time_para` VARCHAR(10),
      `day_para` VARCHAR(20),
      `discipline_id` INT(11) NOT NULL,
      `type_disc_id` INT(11) NOT NULL,
      `teacher_id` INT(11) NOT NULL,
      `auditoriya_id` INT(11) NOT NULL,
      `semester_id` INT(11) NOT NULL,
      `group_id` INT(11) NOT NULL,
      FOREIGN KEY (`discipline_id`) REFERENCES `rz_discipline` (`id`),
      FOREIGN KEY (`teacher_id`) REFERENCES `rz_teacher` (`id`),
      FOREIGN KEY (`auditoriya_id`) REFERENCES `rz_auditoriya` (`id`),
      FOREIGN KEY (`semester_id`) REFERENCES `rz_semester` (`id`),
      FOREIGN KEY (`type_disc_id`) REFERENCES `rz_type_disc` (`id`),
      FOREIGN KEY (`group_id`) REFERENCES `rz_group` (`id`)
    )$charset_collate;";
    dbDelta( $sql );
    //
    //
}

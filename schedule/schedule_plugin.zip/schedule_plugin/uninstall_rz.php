<?php
function rz_uninstall() {
    // удаляем таблицу для хранения расписания занятий
    global $wpdb;

    $table_name = $wpdb->prefix . 'discipline';
    $sql = "DROP TABLE IF EXISTS $table_name;";
    $wpdb->query( $sql );

    //
    //
    $table_name = $wpdb->prefix . 'type_disc';
    $sql = "DROP TABLE IF EXISTS $table_name;";
    $wpdb->query( $sql );
}

?>
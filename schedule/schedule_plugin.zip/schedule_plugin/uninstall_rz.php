<?php



function rz_uninstall() {

    // if uninstall.php is not called by WordPress, die
    if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
        die;
    }
    // удаляем таблицу для хранения расписания занятий
        global $wpdb;

        $table_name = $wpdb->prefix . 'rz_schedule';
        $sql = "DROP TABLE IF EXISTS $table_name;";
        $wpdb->query( $sql );

        //

        $table_name = $wpdb->prefix . 'rz_group';
        $sql = "DROP TABLE IF EXISTS $table_name;";
        $wpdb->query( $sql );
        //

        $table_name = $wpdb->prefix . 'rz_speciality';
        $sql = "DROP TABLE IF EXISTS $table_name;";
        $wpdb->query( $sql );
        //

        $table_name = $wpdb->prefix . 'rz_faculty';
        $sql = "DROP TABLE IF EXISTS $table_name;";
        $wpdb->query( $sql );
        //

        $table_name = $wpdb->prefix . 'rz_teacher';
        $sql = "DROP TABLE IF EXISTS $table_name;";
        $wpdb->query( $sql );
        //

        $table_name = $wpdb->prefix . 'rz_semester';
        $sql = "DROP TABLE IF EXISTS $table_name;";
        $wpdb->query( $sql );
        //

        $table_name = $wpdb->prefix . 'rz_discipline';
        $sql = "DROP TABLE IF EXISTS $table_name;";
        $wpdb->query( $sql );
        //

        $table_name = $wpdb->prefix . 'rz_type_disc';
        $sql = "DROP TABLE IF EXISTS $table_name;";
        $wpdb->query( $sql );
        //

        $table_name = $wpdb->prefix . 'rz_auditoriya';
        $sql = "DROP TABLE IF EXISTS $table_name;";
        $wpdb->query( $sql );

}
/*// if uninstall.php is not called by WordPress, die
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    die;
}

$option_name = 'wporg_option';

delete_option( $option_name );

// for site options in Multisite
delete_site_option( $option_name ); */


?>
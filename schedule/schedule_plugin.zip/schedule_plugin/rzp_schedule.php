<?php
/**
 * Plugin Name: Schedule Plagin
 * Plugin URI: https://example.com/
 * Description: Плагин для чтения, просмотра и сохранения расписания занятий из файла Excel в базе данных WordPress
 * Version: 1.0
 * Author: Arianna
 * Author URI: https://example.com/
 */

// подключаем библиотеку PHPspreadsheet

require 'vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\IOFactory;

// connectopns les fichier d installation et de desinstallation
require_once 'install_rz.php';
require_once 'uninstall_rz.php';

// регистрируем хук, который будет вызываться при активации плагина
register_activation_hook( __FILE__, 'rz_install' );
register_activation_hook( __FILE__, 'rz_install_spec' );
register_activation_hook( __FILE__, 'rz_install_group' );
register_activation_hook( __FILE__, 'rz_install_schedul' );


// регистрируем хук, который будет вызываться при деактивации плагина
register_deactivation_hook( __FILE__, 'rz_uninstall' );



 ?>

